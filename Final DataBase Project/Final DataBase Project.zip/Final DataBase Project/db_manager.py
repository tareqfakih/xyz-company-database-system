import mysql.connector

TABLES = [
    "departments", "persons", "person_phones", "employees",
    "employee_departments", "customers", "potential_employees",
    "jobs", "job_applications", "interviews",
    "products", "marketing_sites", "sales_history",
    "vendors", "parts", "product_parts", "employee_salaries"
]

def connect():
    host = input("Host [localhost]: ") or "localhost"
    user = input("User [root]: ") or "root"
    pwd  = input("Password: ")
    db   = input("Database [project_db]: ") or "project_db"
    try:
        return mysql.connector.connect(
            host=host, user=user, password=pwd, database=db
        )
    except mysql.connector.Error as e:
        print("Connection error:", e)
        return None

def choose_table():
    for i, t in enumerate(TABLES, 1):
        print(f"{i}. {t}")
    while True:
        sel = input(f"Select [1-{len(TABLES)}]: ")
        if sel.isdigit() and 1 <= int(sel) <= len(TABLES):
            return TABLES[int(sel)-1]

def list_tables(conn):
    cur = conn.cursor()
    cur.execute("SHOW TABLES")
    for (t,) in cur:
        print("-", t)
    cur.close()

def view_data(conn):
    tbl = choose_table()
    cur = conn.cursor()
    cur.execute(f"SELECT * FROM {tbl} LIMIT 20")
    print(cur.column_names)
    for row in cur.fetchall():
        print(row)
    cur.close()

def insert_row(conn):
    tbl = choose_table()
    cur = conn.cursor()
    cur.execute(f"DESCRIBE {tbl}")
    desc = cur.fetchall()
    cols = [r[0] for r in desc if not (r[3]=="PRI" and "auto_increment" in r[5])]
    vals = [input(f"{c}: ") for c in cols]
    placeholders = ", ".join(["%s"] * len(cols))
    col_list = ", ".join(cols)
    cur.execute(
        f"INSERT INTO {tbl} ({col_list}) VALUES ({placeholders})", vals
    )
    conn.commit()
    cur.close()

def update_row(conn):
    tbl = choose_table()
    cur = conn.cursor()
    cur.execute(f"DESCRIBE {tbl}")
    desc = cur.fetchall()
    pks = [r[0] for r in desc if r[3]=="PRI"]
    if not pks:
        print("No primary key")
        cur.close()
        return
    where = []
    vals = []
    for pk in pks:
        v = input(f"{pk}: ")
        where.append(f"{pk}=%s")
        vals.append(v)
    fields = [r[0] for r in desc]
    for i, f in enumerate(fields, 1):
        print(f"{i}. {f}")
    choice = int(input(f"Field [1-{len(fields)}]: "))
    field = fields[choice-1]
    newv = input("New value: ")
    cur.execute(
        f"UPDATE {tbl} SET {field}=%s WHERE {' AND '.join(where)}",
        [newv] + vals
    )
    conn.commit()
    cur.close()

def delete_row(conn):
    tbl = choose_table()
    cur = conn.cursor()
    cur.execute(f"DESCRIBE {tbl}")
    desc = cur.fetchall()
    pks = [r[0] for r in desc if r[3]=="PRI"]
    if not pks:
        print("No primary key")
        cur.close()
        return
    where = []
    vals = []
    for pk in pks:
        v = input(f"{pk}: ")
        where.append(f"{pk}=%s")
        vals.append(v)
    cur.execute(
        f"DELETE FROM {tbl} WHERE {' AND '.join(where)}", vals
    )
    conn.commit()
    cur.close()

def custom_sql(conn):
    q = input("SQL> ")
    cur = conn.cursor()
    cur.execute(q)
    if cur.with_rows:
        print(cur.column_names)
        for r in cur.fetchall():
            print(r)
    else:
        print(cur.rowcount, "affected")
    cur.close()

def main():
    conn = connect()
    if not conn:
        return
    while True:
        print("""
1) list tables
2) view data
3) insert row
4) update row
5) delete row
6) custom sql
0) exit
""")
        c = input("Choice: ").strip()
        if c == "1":
            list_tables(conn)
        elif c == "2":
            view_data(conn)
        elif c == "3":
            insert_row(conn)
        elif c == "4":
            update_row(conn)
        elif c == "5":
            delete_row(conn)
        elif c == "6":
            custom_sql(conn)
        elif c == "0":
            break
    conn.close()

if __name__ == "__main__":
    main()
