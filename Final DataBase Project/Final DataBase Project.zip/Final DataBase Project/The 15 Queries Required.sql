
-- Query 1: Interviewers for candidate Hellen Cole in job 11111
SELECT DISTINCT
  e.employee_id,
  CONCAT(p2.first_name, ' ', p2.last_name) AS interviewer_name
FROM interviews AS i
JOIN persons    AS p1 ON i.candidate_person_id = p1.person_id
JOIN employees  AS e  ON i.interviewer_employee_id = e.employee_id
JOIN persons    AS p2 ON e.person_id = p2.person_id
WHERE p1.first_name = 'Hellen'
  AND p1.last_name  = 'Cole'
  AND i.job_id      = 11111;

-- Query 2: IDs of jobs posted by Marketing in January 2011
SELECT j.job_id
FROM jobs        AS j
JOIN departments AS d ON j.dept_id = d.dept_id
WHERE d.dept_name = 'Marketing'
  AND j.posted_date BETWEEN '2011-01-01' AND '2011-01-31';

-- Query 3: Employees with no supervisees
SELECT
  e.employee_id,
  CONCAT(p.first_name, ' ', p.last_name) AS employee_name
FROM employees AS e
JOIN persons   AS p ON e.person_id = p.person_id
WHERE e.employee_id NOT IN (
  SELECT supervisor_id
  FROM employees
  WHERE supervisor_id IS NOT NULL
);

-- Query 4: Marketing sites with no sales in March 2011
SELECT
  ms.site_id,
  ms.location
FROM marketing_sites AS ms
WHERE ms.site_id NOT IN (
  SELECT site_id
  FROM sales_history
  WHERE sale_time BETWEEN '2011-03-01' AND '2011-03-31'
);

-- Query 5: Jobs without a suitable hire one month after posting
SELECT
  j.job_id,
  j.job_description
FROM jobs AS j
WHERE j.job_id NOT IN (
  SELECT i.job_id
  FROM interviews AS i
  GROUP BY i.job_id, i.candidate_person_id
  HAVING AVG(i.grade) > 70
     AND SUM(i.grade > 60) >= 5
);

-- Query 6: Salesmen who sold every product priced over $200
SELECT
  e.employee_id,
  CONCAT(p.first_name, ' ', p.last_name) AS salesman_name
FROM employees AS e
JOIN persons   AS p ON e.person_id = p.person_id
WHERE NOT EXISTS (
  SELECT 1
  FROM products AS pr
  WHERE pr.list_price > 200
    AND NOT EXISTS (
      SELECT 1
      FROM sales_history AS s
      WHERE s.salesman_id = e.employee_id
        AND s.product_id  = pr.product_id
    )
);

-- Query 7: Departments with no job posts between 2011-01-01 and 2011-02-01
SELECT
  d.dept_id,
  d.dept_name
FROM departments AS d
WHERE d.dept_id NOT IN (
  SELECT dept_id
  FROM jobs
  WHERE posted_date BETWEEN '2011-01-01' AND '2011-02-01'
);

-- Query 8: Employees who applied for job 12345 and are currently assigned
SELECT
  e.employee_id,
  CONCAT(p.first_name, ' ', p.last_name) AS employee_name,
  ed.dept_id
FROM employees AS e
JOIN persons            AS p  ON e.person_id = p.person_id
JOIN job_applications  AS ja ON ja.applicant_person_id = e.person_id
JOIN employee_departments AS ed
  ON ed.employee_id = e.employee_id
  AND ed.end_time IS NULL
WHERE ja.job_id = 12345;

-- Query 9: Best-selling product type
SELECT x.product_type
FROM (
  SELECT
    p.product_type,
    COUNT(*) AS sold_count
  FROM sales_history AS s
  JOIN products      AS p ON s.product_id = p.product_id
  GROUP BY p.product_type
) AS x
ORDER BY x.sold_count DESC
LIMIT 1;

-- Query 10: Product type with highest net profit (revenue - cost)
SELECT
  p.product_type
FROM products AS p
JOIN (
  SELECT
    s.product_id,
    SUM(pr.list_price) AS total_revenue
  FROM sales_history AS s
  JOIN products      AS pr ON s.product_id = pr.product_id
  GROUP BY s.product_id
) AS rev ON rev.product_id = p.product_id
JOIN (
  SELECT
    pp.product_id,
    SUM(pp.quantity * pa.price) AS total_cost
  FROM product_parts AS pp
  JOIN parts         AS pa ON pp.part_id = pa.part_id
  GROUP BY pp.product_id
) AS cost ON cost.product_id = p.product_id
ORDER BY (rev.total_revenue - cost.total_cost) DESC
LIMIT 1;

-- Query 11: Employees who have worked in all departments
SELECT
  e.employee_id,
  CONCAT(p.first_name, ' ', p.last_name) AS employee_name
FROM employees AS e
JOIN persons   AS p ON e.person_id = p.person_id
WHERE NOT EXISTS (
  SELECT 1
  FROM departments AS d
  WHERE NOT EXISTS (
    SELECT 1
    FROM employee_departments AS ed
    WHERE ed.employee_id = e.employee_id
      AND ed.dept_id      = d.dept_id
  )
);

-- Query 12: Names and emails of selected interviewees
SELECT
  CONCAT(p.first_name, ' ', p.last_name) AS interviewee_name,
  p.email
FROM persons AS p
WHERE p.person_id IN (
  SELECT i.candidate_person_id
  FROM interviews AS i
  GROUP BY i.candidate_person_id
  HAVING AVG(i.grade) > 70
     AND SUM(i.grade > 60) >= 5
);

-- Query 13: Contact info for interviewees selected for all applied jobs
SELECT DISTINCT
  CONCAT(p.first_name, ' ', p.last_name) AS interviewee_name,
  ph.phone_number
FROM job_applications AS ja
JOIN interviews AS i
  ON ja.applicant_person_id = i.candidate_person_id
  AND ja.job_id             = i.job_id
JOIN persons AS p
  ON p.person_id = ja.applicant_person_id
JOIN person_phones AS ph
  ON ph.person_id = p.person_id
GROUP BY p.person_id, ph.phone_number
HAVING AVG(i.grade) > 70
   AND SUM(i.grade > 60) >= 5;

-- Query 14: Employee with highest average monthly salary
SELECT
  e.employee_id,
  CONCAT(p.first_name, ' ', p.last_name) AS employee_name
FROM avg_monthly_salary AS v
JOIN employees AS e ON v.employee_id = e.employee_id
JOIN persons   AS p ON e.person_id     = p.person_id
ORDER BY v.avg_salary DESC
LIMIT 1;

-- Query 15: Vendor offering 'Cup' part under 4 lbs at lowest price
SELECT
  v.vendor_id,
  v.vendor_name
FROM parts   AS pr
JOIN vendors AS v ON pr.vendor_id = v.vendor_id
WHERE pr.part_name = 'Cup'
  AND pr.weight    < 4
  AND pr.price    = (
    SELECT MIN(price)
    FROM parts
    WHERE part_name = 'Cup'
      AND weight    < 4
  );
