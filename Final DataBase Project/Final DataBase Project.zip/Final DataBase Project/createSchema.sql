-- departments
CREATE TABLE departments (
    dept_id INT PRIMARY KEY,
    dept_name VARCHAR(50) NOT NULL
);

-- persons
CREATE TABLE persons (
    person_id INT PRIMARY KEY,
    last_name VARCHAR(30),
    first_name VARCHAR(30),
    age INT CHECK(age < 65),
    gender ENUM('M', 'F', 'Other'),
    address_line1 VARCHAR(50),
    address_line2 VARCHAR(50),
    city VARCHAR(30),
    state VARCHAR(30),
    zip_code VARCHAR(10)
);

ALTER TABLE persons
  ADD COLUMN email VARCHAR(100);

-- person_phones
CREATE TABLE person_phones (
    person_id INT,
    phone_number VARCHAR(20),
    PRIMARY KEY (person_id, phone_number),
    FOREIGN KEY (person_id) REFERENCES persons(person_id)
);

-- employees
CREATE TABLE employees (
    employee_id INT PRIMARY KEY,
    person_id INT UNIQUE,
    emp_rank VARCHAR(30),
    title VARCHAR(50),
    supervisor_id INT,
    FOREIGN KEY (person_id) REFERENCES persons(person_id),
    FOREIGN KEY (supervisor_id) REFERENCES employees(employee_id)
);

-- employee_departments
CREATE TABLE employee_departments (
    employee_id INT,
    dept_id INT,
    start_time DATETIME,
    end_time DATETIME,
    PRIMARY KEY (employee_id, dept_id, start_time),
    FOREIGN KEY (employee_id) REFERENCES employees(employee_id),
    FOREIGN KEY (dept_id) REFERENCES departments(dept_id)
);

-- customers
CREATE TABLE customers (
    customer_id INT PRIMARY KEY,
    person_id INT UNIQUE,
    preferred_employee_id INT,
    FOREIGN KEY (person_id) REFERENCES persons(person_id),
    FOREIGN KEY (preferred_employee_id) REFERENCES employees(employee_id)
);

-- potential_employees
CREATE TABLE potential_employees (
    potential_emp_id INT PRIMARY KEY,
    person_id INT UNIQUE,
    FOREIGN KEY (person_id) REFERENCES persons(person_id)
);

-- jobs
CREATE TABLE jobs (
    job_id INT PRIMARY KEY,
    dept_id INT,
    job_description TEXT,
    posted_date DATE,
    FOREIGN KEY (dept_id) REFERENCES departments(dept_id)
);

-- job_applications
CREATE TABLE job_applications (
    job_id INT,
    applicant_person_id INT,
    application_date DATE,
    PRIMARY KEY (job_id, applicant_person_id),
    FOREIGN KEY (job_id) REFERENCES jobs(job_id),
    FOREIGN KEY (applicant_person_id) REFERENCES persons(person_id)
);

-- interviews
CREATE TABLE interviews (
    interview_id INT AUTO_INCREMENT PRIMARY KEY,
    job_id INT,
    candidate_person_id INT,
    interviewer_employee_id INT,
    interview_time DATETIME,
    grade INT CHECK(grade BETWEEN 0 AND 100),
    FOREIGN KEY (job_id) REFERENCES jobs(job_id),
    FOREIGN KEY (candidate_person_id) REFERENCES persons(person_id),
    FOREIGN KEY (interviewer_employee_id) REFERENCES employees(employee_id)
);

-- products
CREATE TABLE products (
    product_id INT PRIMARY KEY,
    product_type VARCHAR(50),
    size VARCHAR(20),
    list_price DECIMAL(10,2),
    weight DECIMAL(10,2),
    style VARCHAR(30)
);

-- marketing_sites
CREATE TABLE marketing_sites (
    site_id INT PRIMARY KEY,
    site_name VARCHAR(50),
    location VARCHAR(50)
);

-- sales_history
CREATE TABLE sales_history (
    sale_id INT AUTO_INCREMENT PRIMARY KEY,
    salesman_id INT,
    customer_id INT,
    product_id INT,
    site_id INT,
    sale_time DATETIME,
    FOREIGN KEY (salesman_id) REFERENCES employees(employee_id),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    FOREIGN KEY (site_id) REFERENCES marketing_sites(site_id)
);

-- vendors
CREATE TABLE vendors (
    vendor_id INT PRIMARY KEY,
    vendor_name VARCHAR(50),
    address VARCHAR(100),
    account_number VARCHAR(30),
    credit_rating VARCHAR(20),
    web_service_url VARCHAR(100)
);

-- parts
CREATE TABLE parts (
    part_id INT PRIMARY KEY,
    vendor_id INT,
    part_name VARCHAR(50),
    price DECIMAL(10,2),
    weight DECIMAL(10,2),
    FOREIGN KEY (vendor_id) REFERENCES vendors(vendor_id)
);

-- product_parts
CREATE TABLE product_parts (
    product_id INT,
    part_id INT,
    quantity INT,
    PRIMARY KEY (product_id, part_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    FOREIGN KEY (part_id) REFERENCES parts(part_id)
);

-- employee_salaries
CREATE TABLE employee_salaries (
    employee_id INT,
    transaction_no VARCHAR(20),
    pay_date DATE,
    amount DECIMAL(10,2),
    PRIMARY KEY (employee_id, transaction_no),
    FOREIGN KEY (employee_id) REFERENCES employees(employee_id)
);
